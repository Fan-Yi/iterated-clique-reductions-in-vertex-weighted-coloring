package ConfigPack;

class Config{
}
