package InterfacePack;

public interface IntRelate {
    public boolean related(long a, long b);
}
