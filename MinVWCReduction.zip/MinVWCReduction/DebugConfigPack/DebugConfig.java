package DebugConfigPack;

public class DebugConfig{
	public static final boolean READ_WEIGHT_MODE = true; 
    public static final boolean CALC_PULLAN_WEIGHT_MODE = false;
    public static final boolean CALC_W2_WEIGHT_MODE = false; 
}
