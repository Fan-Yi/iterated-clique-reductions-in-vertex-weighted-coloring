package ZeroParameterInterfacePack;

import java.util.*;

public interface ZeroParameterBehavior {
    public boolean behavior();
}
