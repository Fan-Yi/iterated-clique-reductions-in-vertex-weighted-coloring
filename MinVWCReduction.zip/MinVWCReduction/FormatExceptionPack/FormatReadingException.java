package FormatExceptionPack;

public class FormatReadingException extends Exception{
	public String detail;


}
