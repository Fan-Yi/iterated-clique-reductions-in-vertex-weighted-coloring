package TwoParametersInterfacePack;

import java.util.*;

public interface TwoParametersBehavior {
    public void behavior(ArrayList<Integer> reserved_vertex_list, ArrayList<Integer> last_top_level_weight_updated_colors);
}
